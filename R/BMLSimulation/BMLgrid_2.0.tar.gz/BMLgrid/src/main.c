// 1 represents the blue car, 2 the red car
// and 0 means no car in this cell.

// The blue car moves up along its column,
// so the column of its position stays the same and
// every move increase the row at 1 unit.
// As long as it gets the edge of the grid
// (the end of the number of row),
// it starts at the 1st row of its positon

// The red car moves up along its row,
// so the row of its position stays the same and
// every move increase the column at 1 unit.
// As long as it gets the end of its column,
// it starts at the 1st column of its positon

#include <stdio.h>
#include <string.h>
int cmove(int *grid, int *newgrid, int *carpos, int *ncar, int *dim, int *col){
    
    int j, k, old, change, constant, current, next, length;
    // copy the old grid to the new grid
    memcpy(newgrid, grid, sizeof(int) * dim[0] * dim[1]);
    
    for (int i = 0; i < *ncar; i++) {
        if (*col == 1) {
            k = i;
            j = i + *ncar;
            length = dim[0];
        } else {
            j = i;
            k = i + *ncar;
            length = dim[1];
        }
            
        old = carpos[k];
        change = old + 1;
        // check wether the car gets the edge of the grid
        if (change == length)
            change = 0;
        constant = carpos[j];
        
        if (*col == 1){
            // if the moving car is blue,
            // then only the row of this car change
            next = change+constant*dim[0];
            current = old+constant*dim[0];
        } else {
            // if it is red,
            //then only the column if this car change
            next = constant+change*dim[0];
            current = constant+old*dim[0];
        }
        
        //check wether the next postion is empty.
        if(grid[next] == 0){
            newgrid[current] = 0;
            newgrid[next] = *col;
            // update the car postion if this car moves.
            carpos[k] = change;
        }
        
    }
    return 0;
}




void crunBMLGrid(int *grid, int *newgrid, int *redpos, int *bluepos, int *nblue, int *nred, int *dim, int *numsteps){
    
    for (int i = 1; i <= *numsteps; i++) {
        // if the step is odd, then moving car is blue
        // else, the moving car is red
        if (i % 2 == 1) {
            int col[1] = {1};
            cmove(grid, newgrid, bluepos, nblue, dim, col);
        }else{
            int col[1] = {2};
            cmove(grid, newgrid, redpos, nred, dim, col);
        }
        
        // Update the grid for next iteration
        memcpy(grid, newgrid, sizeof(int) * dim[0] * dim[1]);
    }
}




