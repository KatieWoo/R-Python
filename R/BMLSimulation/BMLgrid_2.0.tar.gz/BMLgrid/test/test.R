library(BMLgrid)
# 1 is blue cars, 2 is red cars
g = matrix(c(0, 0, 1, 2), 2, 2)
# Check runBMLGrid.R
gr = runBMLGrid(g, numsteps = 4)[[1]]

# Check crunBMLGrid.R
gc = crunBMLGrid(g, numsteps = 4)
# Check result from c and r are equal
if (any(gr != gc))
  stop('Error: Different simulation result for 4-step test get from C')

correct = matrix(c(0, 2, 0, 1), 2, 2)
# Check the result
if (any(gr != correct) | any(gr != correct))
  stop('Error: 4-step test failed!')
