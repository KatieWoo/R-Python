createBMLGrid = function(r = c, c = r, ncars = c(red, blue))
  # This function generate a BMLgrid with dimension c*r,
  # with randomly selected red and blue cars.
  # c is the number of columns, r is for row.
  # ncars is the number of cars that may be input as three ways:
  # 1. the number of total cars
  # 2. the number of red cars and blue cars
  # 3. the proportion of cars of all the cells in GMLgrid
  # 0 represents no cars, 1 represents blue cars and 2 represents red cars
{
  # if input is number of cars, 
  # we consider the number of red and blue cars are equal
  if (length(ncars) == 1)
    ncars = rep(ncars/2, 2)
  # if input is car ratio over total cells of grid
  # ncars = ratio*(total cells) = ratio*r*c
  if (any(ncars < 1))
    ncars[ncars < 1] = ncars[ncars < 1]*r*c
  if ((r|c) <= 0 | sum(ncars) <= 0 |sum(ncars) > r*c) {
    stop('Demensions and ncars should be positive integers, ncars should not be more than product of demension')}
  
  grid = matrix(0, r, c)
  # randomly selects cars location out of r*c
  pos = sample(x = r*c, sum(ncars), replace = FALSE)
  # randomly select red and blue cars locations
  grid[pos] = sample(rep(c(2, 1), 
                         ceiling(ncars)))[seq_along(pos)]
  # add a class BMLgrid to grid
  class(grid) = c("BMLgrid", class(grid))
  grid
}

Nextlocation = function(g, color, length, ...)
  # This function returns the BMLgrid with the car moves at one step. 
  # g is the BMLgrid, color is the color of car that we assisgned
  # length is either the length of row or column
  # ... is point at either 'row' or 'col' of the current position
{
  # get the matrix index of cars in certain color, 
  # such as blue and red. 
  current = which(g == color , arr.ind = TRUE)
  # the car moves along its row or col. 
  move = (as.numeric(current[, ...]) + 1)
  # If the car moves to the edge of the grid, 
  # then it starts from the begining: 
  # the first postions of its current row or column
  move[move > length] = 1
  nextl = current
  # only the row or column changed compare to the car's current location
  nextl[, ...] = move
  # If the next position that the car tends to move is not empty,
  # they it is stucked and stay at its current postion. 
  check = (g[nextl] != 0)
  carmove = length(which(check == FALSE))
  carblock = length(which(check == TRUE))
  # We define the Velocity as ratio of the move car 
  # to the total car of certain color, 
  # since only one color moves at one step.
  velocity = carmove/(carmove+carblock)
  nextl[check, ] = current[check, ]
  g[current] = 0
  g[nextl] = color
  list(grid = g, move = carmove, block = carblock, velocity = velocity)
}

moveCars = function(g, color)
  # This function return the BMLgrid 
  # with either red or blue car moves by 1 step
  # color means the color of car that moves
{
  if(color == 1)
    # The blue car moves up along its column,
    # so the column of its position stays the same and
    # every move increase the row at 1 unit. 
    # As long as it gets the edge of the grid
    # (the end of the number of row), 
    # it starts at the 1st row of its positon
    Nextlocation(g = g, color, length = nrow(g), 'row')
  else
    # The red car moves right along its row,
    # so the row of its position stays the same and
    # every move increase the column at 1 unit. 
    # As long as it gets the end of the number of column, 
    # it starts at the 1st column of its positon.
    Nextlocation(g = g, color, length = ncol(g), 'col')
}


runBMLGrid = function(grid, numsteps, allsteps = FALSE)
  # This function return the BMLgrid 
  # after the cars moves by a certain number of steps.
  # g is the first stage of BMLgrid
  # numsteps is the number of moving steps. 
  # if allsteps is ture, then return a list that contains 
  # every stage of grid.
{
  out = c()
  out[[1]] = grid
  for (i in (1:numsteps)){
    # if the time periods is odd, then the blue car moves, 
    # otherwise, the red car moves. 
    if (i%%2 == 1) 
      g = moveCars(grid, color = 1)
    else
      g = moveCars(grid, color = 2)
    grid = g$grid
    if (allsteps){
      out[[i+1]] = g
    } else
      out = g
  }
  out
}

plot.BMLgrid = function(x, ...)
  # This function displays the grid
{
  # Match the color to generate a matrix with numbers not characters
  # each number represents one color
  colmat = match(x, c(2, 1, 0))
  g = matrix(colmat, nrow(x), ncol(x))
  image(t(g), col = c('red', 'blue', 'white'), axes = FALSE, main = 'Car Move Simulation', ...)
  box()
}

summary.BMLgrid = function(object, ...) 
  # This summary funtion returns general inforamtion of the BMLgrid:
  # the dimension, the number of cars, red cars and blue cars, 
  # and the ratio of cars, blue cars, red cars over total cells of BMLgrid
{
  NUM = rbind(Totcar = sum(object != 0),
              redcar = sum(object == 2),
              bluecar = sum(object == 1))
  colnames(NUM) = 'NUM'
  RATIO = NUM/prod(dim(object))
  colnames(RATIO) = 'RATIO'
  list(Demention = dim(object),
       CarsNum = cbind(NUM, RATIO)
  )
}

crunBMLGrid = function(grid, numsteps)
  # This function return the BMLgrid 
  # after the cars moves by a certain number of steps in C routines
  # g is the first stage of BMLgrid
  # numsteps is the number of moving steps. 
{
  dim = dim(grid)
  newgrid = rep(0, length(as.integer(grid)))
  bluepos = which(grid == 1, arr.ind = TRUE) - 1
  nblue = nrow(bluepos)
  redpos = which(grid == 2, arr.ind = TRUE) - 1
  nred = nrow(redpos)
  grid = matrix(.C('crunBMLGrid', 
                   as.integer(grid), 
                   as.integer(newgrid),
                   as.integer(redpos),
                   as.integer(bluepos), 
                   as.integer(nblue),
                   as.integer(nred),
                   as.integer(dim),
                   as.integer(numsteps))[[1]], dim[1], dim[2])
  class(grid) = c("BMLgrid", class(grid))
  grid
}